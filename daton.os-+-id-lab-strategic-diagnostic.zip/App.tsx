
import React, { useState, useEffect } from 'react';
import { DiagnosticData, ReportResult, AppState } from './types';
import { generateStrategicReport } from './geminiService';
import { GRADIENTS, COLORS } from './constants';
import { InputSlider } from './components/InputSlider';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, 
  PieChart, Pie, Cell, LineChart, Line, Legend, 
} from 'recharts';
import { 
  TrendingUp, ShieldAlert, CalendarDays, ChevronRight, Printer, 
  RefreshCcw, Loader2, Sparkles, ArrowRight, DollarSign, Wallet, Percent, Target, ExternalLink,
  Globe, Instagram, CheckCircle2, AlertCircle, Lightbulb
} from 'lucide-react';

const App: React.FC = () => {
  const [step, setStep] = useState<AppState>(AppState.FORM);
  const [loadingMsg, setLoadingMsg] = useState('Analisando variáveis estratégicas...');
  const [formData, setFormData] = useState<DiagnosticData>({
    companyName: '',
    industry: '',
    size: '1-10',
    contactName: '',
    websiteUrl: '',
    instagramHandle: '',
    okrAlignment: 5,
    teamEngagement: 5,
    performanceVisibility: 5,
    feedbackLoop: 5,
    brandCohesion: 5,
    uxQuality: 5,
    strategicDesign: 5,
    marketPositioning: 5,
    monthlyRevenue: 50000,
    averageTicket: 500,
    conversionRate: 10,
    marketingInvestment: 2000,
    biggestPainPoint: '',
    currentObjective: ''
  });
  const [report, setReport] = useState<ReportResult | null>(null);

  const loadingMessages = [
    "Avaliando a eficiência da sua gestão...",
    "Auditando seu site e redes sociais...",
    "Pesquisando benchmarks do mercado brasileiro...",
    "Calculando impacto visual e posicionamento...",
    "Projetando retorno financeiro sobre ações...",
    "Finalizando dashboards didáticos..."
  ];

  useEffect(() => {
    let interval: any;
    if (step === AppState.ANALYZING) {
      let i = 0;
      interval = setInterval(() => {
        setLoadingMsg(loadingMessages[i % loadingMessages.length]);
        i++;
      }, 2500);
    }
    return () => clearInterval(interval);
  }, [step]);

  const handleSubmit = async () => {
    if (!formData.companyName) {
      alert("Por favor, preencha o nome da empresa.");
      return;
    }
    setStep(AppState.ANALYZING);
    try {
      const result = await generateStrategicReport(formData);
      setReport(result);
      setStep(AppState.REPORT);
      window.scrollTo(0, 0);
    } catch (error) {
      console.error(error);
      alert("Erro ao gerar diagnóstico. Verifique sua conexão ou se preencheu os campos básicos.");
      setStep(AppState.FORM);
    }
  };

  const getScoreColor = (score: number) => {
    if (score <= 4) return '#ef4444'; // Vermelho
    if (score <= 7) return '#f59e0b'; // Amarelo
    return '#10b981'; // Verde
  };

  if (step === AppState.ANALYZING) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-black p-6 text-center">
        <div className="relative mb-8">
          <div className="absolute inset-0 blur-2xl opacity-30 animate-pulse bg-blue-600"></div>
          <Loader2 size={80} className="text-blue-500 animate-spin relative z-10" />
        </div>
        <h2 className="text-2xl font-bold mb-2 tracking-tight">Construindo sua Estratégia</h2>
        <p className="text-zinc-400 max-w-sm mx-auto animate-pulse">{loadingMsg}</p>
      </div>
    );
  }

  if (step === AppState.REPORT && report) {
    const allScores = [
      formData.okrAlignment, formData.teamEngagement, formData.performanceVisibility, formData.feedbackLoop,
      formData.brandCohesion, formData.uxQuality, formData.strategicDesign, formData.marketPositioning
    ];
    const avgScore = Number((allScores.reduce((a, b) => a + b, 0) / allScores.length).toFixed(1));
    const maturityData = [
      { name: 'Críticos', value: allScores.filter(s => s <= 4).length, color: '#ef4444' },
      { name: 'Médios', value: allScores.filter(s => s >= 5 && s <= 7).length, color: '#f59e0b' },
      { name: 'Maduros', value: allScores.filter(s => s >= 8).length, color: '#10b981' },
    ].filter(d => d.value > 0);

    return (
      <div className="min-h-screen bg-zinc-950 p-4 md:p-8">
        <header className="max-w-6xl mx-auto flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4 no-print">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="text-xs font-bold uppercase tracking-widest text-blue-500">Relatório Estratégico</span>
              <div className="h-px w-8 bg-zinc-800"></div>
            </div>
            <h1 className="text-3xl font-bold tracking-tight">{formData.companyName}</h1>
            <p className="text-zinc-500">{formData.industry} • Diagnóstico Daton & Id Lab</p>
          </div>
          <div className="flex gap-3">
            <button onClick={() => setStep(AppState.FORM)} className="px-4 py-2 bg-zinc-900 border border-zinc-800 text-zinc-300 rounded-lg hover:bg-zinc-800 transition-colors flex items-center gap-2">
              <RefreshCcw size={16} /> Refazer
            </button>
            <button onClick={() => window.print()} className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-500 transition-colors flex items-center gap-2 shadow-lg shadow-blue-900/20">
              <Printer size={16} /> Salvar PDF
            </button>
          </div>
        </header>

        <main className="max-w-6xl mx-auto space-y-8">
          {/* Dashboards de Maturidade e Mercado */}
          <section className="grid md:grid-cols-2 gap-6">
            {/* Maturidade Geral da Empresa */}
            <div className="p-6 rounded-2xl bg-zinc-900 border border-zinc-800 print-card relative overflow-hidden">
               <h3 className="text-sm font-bold uppercase text-zinc-400 mb-4 text-center">Maturidade Geral da Empresa</h3>
               <div className="h-56 w-full relative">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie data={maturityData} innerRadius={60} outerRadius={80} paddingAngle={5} dataKey="value">
                      {maturityData.map((entry, index) => <Cell key={`cell-${index}`} fill={entry.color} />)}
                    </Pie>
                  </PieChart>
                </ResponsiveContainer>
                {/* Score central */}
                <div className="absolute inset-0 flex flex-col items-center justify-center">
                  <span className="text-5xl font-black leading-none" style={{ color: getScoreColor(avgScore) }}>{avgScore}</span>
                  <span className="text-[10px] text-zinc-500 font-bold uppercase mt-1">Nota Global</span>
                </div>
               </div>
               <div className="flex justify-center gap-4 mt-2">
                 {maturityData.map(d => (
                   <div key={d.name} className="flex items-center gap-1">
                     <div className="w-2 h-2 rounded-full" style={{backgroundColor: d.color}}></div>
                     <span className="text-[10px] text-zinc-400 font-bold uppercase">{d.name}</span>
                   </div>
                 ))}
               </div>
            </div>

            {/* Comparativo de Mercado */}
            <div className="p-6 rounded-2xl bg-zinc-900 border border-zinc-800 print-card">
              <h3 className="text-sm font-bold uppercase text-zinc-400 mb-4 text-center">Sua Empresa vs Mercado (Benchmark)</h3>
              <div className="h-56 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={report.benchmarks} margin={{ top: 20, right: 30, left: 0, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#222" vertical={false} />
                    <XAxis dataKey="category" stroke="#666" fontSize={10} axisLine={false} tickLine={false} />
                    <YAxis domain={[0, 10]} hide />
                    <Tooltip 
                      contentStyle={{ backgroundColor: '#18181b', border: '1px solid #333', borderRadius: '8px' }}
                    />
                    <Legend iconType="circle" wrapperStyle={{ fontSize: '10px', paddingTop: '10px' }} />
                    <Bar name="Você" dataKey="companyValue" fill="#3b82f6" radius={[4, 4, 0, 0]} barSize={20} />
                    <Bar name="Mercado" dataKey="marketAverage" fill="#52525b" radius={[4, 4, 0, 0]} barSize={20} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
              <p className="text-[9px] text-zinc-600 mt-4 italic text-center uppercase tracking-widest">
                Dados comparativos baseados em sua faixa de faturamento (R$ {formData.monthlyRevenue.toLocaleString()})
              </p>
            </div>
          </section>

          {/* Auditoria Digital */}
          <section className="p-8 rounded-2xl bg-zinc-900 border border-zinc-800 print-card">
            <div className="flex items-center gap-3 mb-8">
              <Globe className="text-blue-500" />
              <h3 className="text-2xl font-bold">Auditoria de Presença Digital</h3>
            </div>

            <div className="grid md:grid-cols-2 gap-8">
              <div className="space-y-6">
                <div className="flex items-center gap-3 pb-2 border-b border-zinc-800">
                  <Globe size={20} className="text-zinc-400" />
                  <h4 className="font-bold text-lg">Website</h4>
                </div>
                <div className="space-y-4">
                  <div>
                    <span className="text-[10px] font-bold text-emerald-500 uppercase flex items-center gap-1 mb-2"><CheckCircle2 size={12}/> O que está bom</span>
                    <ul className="space-y-1">
                      {report.onlinePresence.website.positives.map((p, i) => <li key={i} className="text-xs text-zinc-400">• {p}</li>)}
                    </ul>
                  </div>
                  <div>
                    <span className="text-[10px] font-bold text-red-500 uppercase flex items-center gap-1 mb-2"><AlertCircle size={12}/> O que precisa mudar</span>
                    <ul className="space-y-1">
                      {report.onlinePresence.website.negatives.map((p, i) => <li key={i} className="text-xs text-zinc-400">• {p}</li>)}
                    </ul>
                  </div>
                </div>
              </div>

              <div className="space-y-6">
                <div className="flex items-center gap-3 pb-2 border-b border-zinc-800">
                  <Instagram size={20} className="text-zinc-400" />
                  <h4 className="font-bold text-lg">Instagram</h4>
                </div>
                <div className="space-y-4">
                  <div>
                    <span className="text-[10px] font-bold text-emerald-500 uppercase flex items-center gap-1 mb-2"><CheckCircle2 size={12}/> O que está bom</span>
                    <ul className="space-y-1">
                      {report.onlinePresence.instagram.positives.map((p, i) => <li key={i} className="text-xs text-zinc-400">• {p}</li>)}
                    </ul>
                  </div>
                  <div>
                    <span className="text-[10px] font-bold text-red-500 uppercase flex items-center gap-1 mb-2"><AlertCircle size={12}/> O que precisa mudar</span>
                    <ul className="space-y-1">
                      {report.onlinePresence.instagram.negatives.map((p, i) => <li key={i} className="text-xs text-zinc-400">• {p}</li>)}
                    </ul>
                  </div>
                </div>
              </div>
            </div>
            <div className="mt-8 p-4 bg-zinc-800/30 rounded-xl border border-zinc-800">
              <h5 className="text-xs font-bold text-zinc-500 uppercase mb-2">Estratégia Digital Recomendada</h5>
              <p className="text-sm text-zinc-300 leading-relaxed italic">{report.onlinePresence.strategySummary}</p>
            </div>
          </section>

          {/* Resumo Executivo */}
          <section className="p-6 rounded-2xl bg-zinc-900 border border-zinc-800 print-card">
            <div className="flex items-center gap-3 mb-4">
              <Sparkles className="text-blue-500" size={20} />
              <h3 className="text-xl font-bold">Diagnóstico do Consultor</h3>
            </div>
            <p className="text-zinc-400 leading-relaxed text-sm md:text-base whitespace-pre-line">
              {report.executiveSummary}
            </p>
          </section>

          {/* Roadmap 90 Dias */}
          <section className="p-8 rounded-2xl bg-zinc-900 border border-zinc-800 print-card">
            <div className="flex items-center gap-3 mb-8">
              <CalendarDays className="text-purple-500" />
              <h3 className="text-2xl font-bold">Plano de Ação (Próximos 90 Dias)</h3>
            </div>
            <div className="space-y-12">
              {report.roadmap.map((month, idx) => (
                <div key={idx} className="relative pl-8 border-l border-zinc-800">
                  <div className="absolute -left-3 top-0 w-6 h-6 rounded-full bg-zinc-900 border-2 border-purple-500 flex items-center justify-center font-bold text-xs text-purple-500">
                    {idx + 1}
                  </div>
                  <h4 className="text-lg font-bold text-zinc-100 mb-4 uppercase tracking-widest">{month.month}</h4>
                  <div className="grid md:grid-cols-2 gap-8">
                    <div>
                      <span className="text-xs font-bold text-zinc-500 uppercase block mb-3">Objetivos</span>
                      <ul className="space-y-2">
                        {month.objectives.map((obj, i) => (
                          <li key={i} className="text-zinc-400 text-sm flex gap-2">
                             <div className="mt-1.5 w-1 h-1 rounded-full bg-zinc-700 flex-shrink-0" />
                             {obj}
                          </li>
                        ))}
                      </ul>
                    </div>
                    <div>
                      <span className="text-xs font-bold text-zinc-500 uppercase block mb-3">Ações</span>
                      <div className="space-y-4">
                        {month.actions.map((action, i) => (
                          <div key={i} className="p-3 bg-zinc-800/50 rounded-lg border border-zinc-800/50">
                            <div className="flex justify-between items-start mb-1">
                              <span className="font-semibold text-sm text-zinc-200">{action.task}</span>
                              <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold uppercase ${
                                action.priority === 'Alta' ? 'bg-red-500/10 text-red-500' : 
                                action.priority === 'Média' ? 'bg-orange-500/10 text-orange-500' : 'bg-blue-500/10 text-blue-500'
                              }`}>
                                {action.priority}
                              </span>
                            </div>
                            <p className="text-[11px] text-zinc-500 italic">{action.benefit}</p>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </section>

          {/* Projeção de Faturamento */}
          <section className="p-8 rounded-2xl bg-zinc-900 border border-zinc-800 print-card">
            <div className="mb-8">
              <h3 className="text-2xl font-bold flex items-center gap-2">
                <TrendingUp className="text-emerald-500" /> Projeção de Faturamento
              </h3>
              <p className="text-zinc-500 text-sm">Comparativo de implementação vs. inércia</p>
            </div>
            <div className="h-80 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={report.revenueProjections} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#222" vertical={false} />
                  <XAxis dataKey="month" stroke="#666" fontSize={12} tickLine={false} axisLine={false} />
                  <YAxis stroke="#666" fontSize={12} tickLine={false} axisLine={false} tickFormatter={(v) => `R$ ${(v/1000).toFixed(0)}k`} />
                  <Tooltip 
                    contentStyle={{ backgroundColor: '#18181b', border: '1px solid #333', borderRadius: '8px' }}
                    formatter={(v: number) => [`R$ ${v.toLocaleString('pt-BR')}`, '']}
                  />
                  <Legend verticalAlign="top" height={36} iconType="line" />
                  <Line name="Não aplicar o plano" type="monotone" dataKey="currentScenario" stroke="#52525b" strokeWidth={3} dot={{ r: 4, fill: '#52525b' }} />
                  <Line name="Implementar Daton + Id Lab" type="monotone" dataKey="optimizedScenario" stroke="#10b981" strokeWidth={4} dot={{ r: 5, fill: '#10b981' }} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </section>

          {/* Call to Action Final */}
          <section className="bg-gradient-to-r from-blue-900/40 to-red-900/40 p-10 rounded-3xl text-center border border-zinc-800 no-print">
            <h2 className="text-2xl font-bold mb-4">Pronto para dar o próximo passo?</h2>
            <p className="text-zinc-300 mb-8 max-w-xl mx-auto">
              Este diagnóstico revela que sua empresa tem um grande potencial reprimido por desalinhamento estratégico.
              Vamos unir a eficiência do <b>Daton.os</b> com o design estratégico da <b>Id Lab</b>.
            </p>
            <div className="flex justify-center">
              <a 
                href={`https://wa.me/5521993032334?text=Olá, finalizei o diagnóstico estratégico para a empresa ${formData.companyName} e gostaria de implantar o plano de ação sugerido.`} 
                target="_blank" 
                className="px-10 py-4 bg-emerald-600 text-white font-bold rounded-full hover:bg-emerald-500 hover:scale-105 transition-all shadow-xl shadow-emerald-900/40 flex items-center gap-2 text-lg"
              >
                Implantar Plano de Ação <ArrowRight size={22} />
              </a>
            </div>
          </section>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black text-white font-sans">
      <div className={`fixed top-0 w-full z-50 p-4 ${GRADIENTS.header} backdrop-blur-sm border-b border-white/5`}>
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-red-600 to-blue-600 flex items-center justify-center font-bold text-white shadow-lg shadow-blue-500/20">D</div>
            <span className="text-xl font-bold tracking-tight">Daton<span className="text-blue-500">.os</span> & <span className="text-red-500">Id Lab</span></span>
          </div>
          <button onClick={() => window.open('https://www.idlab.art.br/')} className="px-4 py-1.5 bg-zinc-800 hover:bg-zinc-700 text-white text-sm font-semibold rounded-full border border-white/10 transition-all">Site Oficial</button>
        </div>
      </div>

      <div className="pt-24 pb-12 px-4">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
             <h1 className="text-4xl md:text-6xl font-black mb-4 tracking-tighter leading-tight uppercase">
               Diagnóstico <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-500 to-red-500">Empresarial</span>
             </h1>
             <p className="text-zinc-500 text-lg max-w-2xl mx-auto italic">
               O primeiro passo para o crescimento escalável através de gestão e design.
             </p>
          </div>

          <div className="bg-zinc-900/50 p-6 md:p-10 rounded-3xl border border-zinc-800 shadow-2xl">
              <div className="mb-10">
                <h3 className="text-lg font-bold mb-6 flex items-center gap-3">
                  <div className="w-1.5 h-6 bg-blue-500 rounded-full"></div>
                  1. Perfil do Negócio
                </h3>
                <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <label className="text-[10px] font-bold text-zinc-500 uppercase mb-2 block tracking-widest">Nome da Empresa *</label>
                      <input type="text" placeholder="Qual o nome da sua empresa?" className="w-full bg-zinc-800 border border-zinc-700 rounded-xl px-4 py-3 focus:outline-none focus:border-blue-500 transition-colors" value={formData.companyName} onChange={(e) => setFormData({...formData, companyName: e.target.value})} />
                    </div>
                    <div>
                      <label className="text-[10px] font-bold text-zinc-500 uppercase mb-2 block tracking-widest">Setor de Atuação</label>
                      <input type="text" placeholder="Ex: Estética, E-commerce, SaaS..." className="w-full bg-zinc-800 border border-zinc-700 rounded-xl px-4 py-3 focus:outline-none focus:border-blue-500 transition-colors" value={formData.industry} onChange={(e) => setFormData({...formData, industry: e.target.value})} />
                    </div>
                </div>
              </div>

              {/* Presença Digital */}
              <div className="mb-10 p-6 bg-blue-900/5 rounded-2xl border border-blue-900/10">
                <h3 className="text-lg font-bold mb-6 flex items-center gap-3">
                  <div className="w-1.5 h-6 bg-blue-400 rounded-full"></div>
                  2. Presença Digital
                </h3>
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <label className="text-[10px] font-bold text-zinc-500 uppercase mb-2 block tracking-widest flex items-center gap-1"><Globe size={10}/> Site (URL completa)</label>
                    <input type="text" placeholder="Ex: https://www.seusite.com.br ou www.seusite.com" className="w-full bg-zinc-800 border border-zinc-700 rounded-xl px-4 py-3 focus:outline-none focus:border-blue-400 transition-colors" value={formData.websiteUrl} onChange={(e) => setFormData({...formData, websiteUrl: e.target.value})} />
                  </div>
                  <div>
                    <label className="text-[10px] font-bold text-zinc-500 uppercase mb-2 block tracking-widest flex items-center gap-1"><Instagram size={10}/> Instagram (Ex: @suaempresa)</label>
                    <input type="text" placeholder="@suaempresa" className="w-full bg-zinc-800 border border-zinc-700 rounded-xl px-4 py-3 focus:outline-none focus:border-pink-400 transition-colors" value={formData.instagramHandle} onChange={(e) => setFormData({...formData, instagramHandle: e.target.value})} />
                  </div>
                </div>
              </div>

              {/* Financeiro */}
              <div className="mb-10 p-6 bg-emerald-900/5 rounded-2xl border border-emerald-900/20">
                <h3 className="text-lg font-bold mb-6 flex items-center gap-3">
                  <div className="w-1.5 h-6 bg-emerald-500 rounded-full"></div>
                  3. Indicadores Financeiros
                </h3>
                <div className="grid md:grid-cols-2 gap-x-12 gap-y-6">
                  <div>
                    <label className="text-[10px] font-bold text-zinc-500 uppercase mb-2 block tracking-widest flex items-center gap-1"><DollarSign size={10}/> Faturamento Mensal (R$)</label>
                    <input type="number" className="w-full bg-zinc-800 border border-zinc-700 rounded-xl px-4 py-3 focus:outline-none focus:border-emerald-500" value={formData.monthlyRevenue} onChange={(e) => setFormData({...formData, monthlyRevenue: Number(e.target.value)})} />
                  </div>
                  <div>
                    <label className="text-[10px] font-bold text-zinc-500 uppercase mb-2 block tracking-widest flex items-center gap-1"><Wallet size={10}/> Ticket Médio (R$)</label>
                    <input type="number" className="w-full bg-zinc-800 border border-zinc-700 rounded-xl px-4 py-3 focus:outline-none focus:border-emerald-500" value={formData.averageTicket} onChange={(e) => setFormData({...formData, averageTicket: Number(e.target.value)})} />
                  </div>
                  <div>
                    <label className="text-[10px] font-bold text-zinc-500 uppercase mb-2 block tracking-widest flex items-center gap-1"><Percent size={10}/> Conversão de Vendas (%)</label>
                    <input type="number" className="w-full bg-zinc-800 border border-zinc-700 rounded-xl px-4 py-3 focus:outline-none focus:border-emerald-500" value={formData.conversionRate} onChange={(e) => setFormData({...formData, conversionRate: Number(e.target.value)})} />
                  </div>
                  <div>
                    <label className="text-[10px] font-bold text-zinc-500 uppercase mb-2 block tracking-widest flex items-center gap-1"><Target size={10}/> Verba de Marketing (R$)</label>
                    <input type="number" className="w-full bg-zinc-800 border border-zinc-700 rounded-xl px-4 py-3 focus:outline-none focus:border-emerald-500" value={formData.marketingInvestment} onChange={(e) => setFormData({...formData, marketingInvestment: Number(e.target.value)})} />
                  </div>
                </div>
              </div>

              {/* Avaliações de Nível */}
              <div className="mb-10">
                <h3 className="text-lg font-bold mb-6 flex items-center gap-3">
                  <div className="w-1.5 h-6 bg-red-500 rounded-full"></div>
                  4. Gestão e Pessoas (Daton.os)
                </h3>
                <div className="grid md:grid-cols-2 gap-x-12">
                  <InputSlider label="Clareza de Metas" value={formData.okrAlignment} onChange={(v) => setFormData({...formData, okrAlignment: v})} color={COLORS.primary} />
                  <InputSlider label="Engajamento do Time" value={formData.teamEngagement} onChange={(v) => setFormData({...formData, teamEngagement: v})} color={COLORS.primary} />
                  <InputSlider label="Controle de Dados" value={formData.performanceVisibility} onChange={(v) => setFormData({...formData, performanceVisibility: v})} color={COLORS.primary} />
                  <InputSlider label="Rotina de Feedback" value={formData.feedbackLoop} onChange={(v) => setFormData({...formData, feedbackLoop: v})} color={COLORS.primary} />
                </div>
              </div>

              <div className="mb-10">
                <h3 className="text-lg font-bold mb-6 flex items-center gap-3">
                  <div className="w-1.5 h-6 bg-purple-500 rounded-full"></div>
                  5. Design e Valor (Id Lab)
                </h3>
                <div className="grid md:grid-cols-2 gap-x-12">
                  <InputSlider label="Identidade Visual" value={formData.brandCohesion} onChange={(v) => setFormData({...formData, brandCohesion: v})} color={COLORS.accent} />
                  <InputSlider label="Experiência do Cliente" value={formData.uxQuality} onChange={(v) => setFormData({...formData, uxQuality: v})} color={COLORS.accent} />
                  <InputSlider label="Diferenciação Visual" value={formData.strategicDesign} onChange={(v) => setFormData({...formData, strategicDesign: v})} color={COLORS.accent} />
                  <InputSlider label="Posicionamento Premium" value={formData.marketPositioning} onChange={(v) => setFormData({...formData, marketPositioning: v})} color={COLORS.accent} />
                </div>
              </div>

              <div className="mb-12">
                <h3 className="text-lg font-bold mb-6 flex items-center gap-3"><div className="w-1.5 h-6 bg-zinc-400 rounded-full"></div> Detalhes Estratégicos</h3>
                <div className="space-y-6">
                  <div>
                    <label className="text-[10px] font-bold text-zinc-500 uppercase mb-2 block tracking-widest">Qual a sua meta ou objetivo principal?</label>
                    <input type="text" placeholder="Ex: Dobrar o faturamento, abrir filial, estruturar processos..." className="w-full bg-zinc-800 border border-zinc-700 rounded-xl px-4 py-3 focus:outline-none focus:border-blue-500 transition-colors" value={formData.currentObjective} onChange={(e) => setFormData({...formData, currentObjective: e.target.value})} />
                  </div>
                  <div>
                    <label className="text-[10px] font-bold text-zinc-500 uppercase mb-2 block tracking-widest">Qual seu maior desafio atual?</label>
                    <textarea rows={3} placeholder="O que mais tira seu sono hoje?" className="w-full bg-zinc-800 border border-zinc-700 rounded-xl px-4 py-3 focus:outline-none focus:border-blue-500 transition-colors" value={formData.biggestPainPoint} onChange={(e) => setFormData({...formData, biggestPainPoint: e.target.value})} />
                  </div>
                </div>
              </div>

              <button 
                onClick={handleSubmit} 
                className={`w-full py-5 rounded-2xl font-bold text-lg transition-all flex items-center justify-center gap-3 shadow-2xl ${!formData.companyName ? 'bg-zinc-800 text-zinc-600 cursor-not-allowed' : 'bg-gradient-to-r from-blue-600 to-red-600 text-white hover:scale-[1.01] active:scale-[0.99] shadow-blue-500/20'}`}
              >
                Analisar e Gerar Plano <ChevronRight size={24} />
              </button>
              {!formData.companyName && (
                <p className="text-center text-xs text-red-500/60 mt-4">Preencha o Nome da Empresa para habilitar o diagnóstico.</p>
              )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default App;
