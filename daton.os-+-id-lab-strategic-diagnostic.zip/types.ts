
export interface DiagnosticData {
  companyName: string;
  industry: string;
  size: string;
  contactName: string;
  // Presença Digital
  websiteUrl: string;
  instagramHandle: string;
  // Management (Linguagem Simples)
  okrAlignment: number; 
  teamEngagement: number;
  performanceVisibility: number;
  feedbackLoop: number;
  // Design (Linguagem Simples)
  brandCohesion: number;
  uxQuality: number;
  strategicDesign: number;
  marketPositioning: number;
  // Vendas e Finanças
  monthlyRevenue: number;
  averageTicket: number;
  conversionRate: number;
  marketingInvestment: number;
  // Qualitativo
  biggestPainPoint: string;
  currentObjective: string;
}

export interface ActionItem {
  task: string;
  priority: 'Baixa' | 'Média' | 'Alta';
  benefit: string;
}

export interface MonthPlan {
  month: string;
  objectives: string[];
  actions: ActionItem[];
}

export interface ProjectionData {
  month: string;
  currentScenario: number;
  optimizedScenario: number;
}

export interface BenchmarkData {
  category: string;
  companyValue: number;
  marketAverage: number;
}

export interface DigitalPresenceEvaluation {
  positives: string[];
  negatives: string[];
  insights: string[];
}

export interface ReportResult {
  executiveSummary: string;
  opportunities: string[];
  risks: string[];
  roadmap: MonthPlan[];
  revenueProjections: ProjectionData[];
  benchmarks: BenchmarkData[];
  sources: { title: string; url: string }[];
  onlinePresence: {
    website: DigitalPresenceEvaluation;
    instagram: DigitalPresenceEvaluation;
    strategySummary: string;
  };
  consultantNotes: string;
}

export enum AppState {
  FORM = 'FORM',
  ANALYZING = 'ANALYZING',
  REPORT = 'REPORT'
}
