
import { GoogleGenAI, Type } from "@google/genai";
import { DiagnosticData, ReportResult } from "./types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export async function generateStrategicReport(data: DiagnosticData): Promise<ReportResult> {
  const prompt = `
    Aja como um consultor sênior da Daton.os e Id Lab. Analise a empresa "${data.companyName}" do setor "${data.industry}".
    
    CANAIS DIGITAIS PARA ANÁLISE:
    - Site: ${data.websiteUrl || 'Não informado'}
    - Instagram: ${data.instagramHandle || 'Não informado'}
    
    DADOS DE NEGÓCIO E OBJETIVOS:
    - Faturamento Mensal: R$ ${data.monthlyRevenue}
    - Conversão atual: ${data.conversionRate}%
    - Ticket Médio: R$ ${data.averageTicket}
    - META / OBJETIVO PRINCIPAL: ${data.currentObjective || 'Não informado'}
    - MAIOR DESAFIO ATUAL: ${data.biggestPainPoint || 'Não informado'}
    
    NOTAS (1-10):
    - Gestão: Clareza de Metas (${data.okrAlignment}), Engajamento do Time (${data.teamEngagement}), Controle de Dados (${data.performanceVisibility}), Rotina de Diálogo (${data.feedbackLoop})
    - Design: Identidade de Marca (${data.brandCohesion}), Facilidade de Compra/UX (${data.uxQuality}), Diferenciação Estratégica (${data.strategicDesign}), Valor Percebido/Posicionamento (${data.marketPositioning})

    TAREFA:
    1. Utilize o Google Search para avaliar a presença online da empresa através dos links fornecidos (${data.websiteUrl} e ${data.instagramHandle}). 
    2. Se os links não puderem ser acessados, baseie sua análise em empresas de alto padrão no setor "${data.industry}" para gerar insights comparativos.
    3. Gere uma auditoria didática do Site e do Instagram: Pontos Positivos, Negativos e Insights de melhoria.
    4. Crie uma estratégia resumida de redes sociais para os próximos 90 dias que ajude a alcançar o objetivo: "${data.currentObjective}".
    5. Compare com benchmarks do mercado brasileiro para o faturamento de R$ ${data.monthlyRevenue}.
    6. Retorne um JSON didático para o empresário, evitando termos técnicos complexos.

    SCHEMA DE RESPOSTA (Obrigatório):
    - onlinePresence: {
        website: { positives: string[], negatives: string[], insights: string[] },
        instagram: { positives: string[], negatives: string[], insights: string[] },
        strategySummary: string
      }
    - executiveSummary: string (didático, conectando a situação atual com a meta de "${data.currentObjective}")
    - opportunities: string[]
    - risks: string[]
    - roadmap: monthPlans[] (Month 1, 2, 3)
    - revenueProjections: data[] (6 meses)
    - benchmarks: categoryComparison[] (Comparando empresa vs mercado)
    - sources: { title: string, url: string }[] (Links reais ou referências de mercado)
    - consultantNotes: string
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-pro-preview",
      contents: prompt,
      config: {
        tools: [{ googleSearch: {} }],
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            executiveSummary: { type: Type.STRING },
            opportunities: { type: Type.ARRAY, items: { type: Type.STRING } },
            risks: { type: Type.ARRAY, items: { type: Type.STRING } },
            onlinePresence: {
              type: Type.OBJECT,
              properties: {
                website: {
                  type: Type.OBJECT,
                  properties: {
                    positives: { type: Type.ARRAY, items: { type: Type.STRING } },
                    negatives: { type: Type.ARRAY, items: { type: Type.STRING } },
                    insights: { type: Type.ARRAY, items: { type: Type.STRING } }
                  }
                },
                instagram: {
                  type: Type.OBJECT,
                  properties: {
                    positives: { type: Type.ARRAY, items: { type: Type.STRING } },
                    negatives: { type: Type.ARRAY, items: { type: Type.STRING } },
                    insights: { type: Type.ARRAY, items: { type: Type.STRING } }
                  }
                },
                strategySummary: { type: Type.STRING }
              }
            },
            roadmap: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  month: { type: Type.STRING },
                  objectives: { type: Type.ARRAY, items: { type: Type.STRING } },
                  actions: {
                    type: Type.ARRAY,
                    items: {
                      type: Type.OBJECT,
                      properties: {
                        task: { type: Type.STRING },
                        priority: { type: Type.STRING },
                        benefit: { type: Type.STRING }
                      },
                      required: ["task", "priority", "benefit"]
                    }
                  }
                },
                required: ["month", "objectives", "actions"]
              }
            },
            revenueProjections: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  month: { type: Type.STRING },
                  currentScenario: { type: Type.NUMBER },
                  optimizedScenario: { type: Type.NUMBER }
                },
                required: ["month", "currentScenario", "optimizedScenario"]
              }
            },
            benchmarks: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  category: { type: Type.STRING },
                  companyValue: { type: Type.NUMBER },
                  marketAverage: { type: Type.NUMBER }
                },
                required: ["category", "companyValue", "marketAverage"]
              }
            },
            sources: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  title: { type: Type.STRING },
                  url: { type: Type.STRING }
                }
              }
            },
            consultantNotes: { type: Type.STRING }
          },
          required: ["executiveSummary", "opportunities", "risks", "onlinePresence", "roadmap", "revenueProjections", "benchmarks", "sources", "consultantNotes"]
        }
      }
    });

    return JSON.parse(response.text || "{}") as ReportResult;
  } catch (error) {
    console.error("Erro na chamada Gemini:", error);
    throw error;
  }
}
