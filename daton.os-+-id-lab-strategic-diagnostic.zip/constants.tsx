
import React from 'react';

export const COLORS = {
  primary: '#3b82f6', // blue
  secondary: '#ef4444', // red
  accent: '#a855f7', // purple
  bg: '#050505',
  card: '#121212',
  text: '#ffffff',
  muted: '#9ca3af'
};

export const GRADIENTS = {
  brand: 'bg-gradient-to-r from-red-600 via-purple-600 to-blue-600',
  card: 'bg-gradient-to-br from-zinc-900 to-black',
  header: 'bg-gradient-to-b from-zinc-900/50 to-transparent'
};
