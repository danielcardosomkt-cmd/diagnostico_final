
import React from 'react';

interface InputSliderProps {
  label: string;
  value: number;
  onChange: (val: number) => void;
  color: string;
}

export const InputSlider: React.FC<InputSliderProps> = ({ label, value, onChange, color }) => {
  return (
    <div className="mb-6">
      <div className="flex justify-between items-center mb-2">
        <label className="text-sm font-medium text-zinc-300">{label}</label>
        <span className={`text-lg font-bold px-3 py-1 rounded bg-zinc-800 border border-zinc-700`} style={{ color }}>
          {value}/10
        </span>
      </div>
      <input
        type="range"
        min="1"
        max="10"
        value={value}
        onChange={(e) => onChange(parseInt(e.target.value))}
        className="w-full h-2 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-blue-500"
      />
      <div className="flex justify-between text-[10px] text-zinc-500 mt-1 uppercase tracking-wider">
        <span>Crítico</span>
        <span>Excelente</span>
      </div>
    </div>
  );
};
